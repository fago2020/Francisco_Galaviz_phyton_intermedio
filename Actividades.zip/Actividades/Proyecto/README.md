# Rovobak API

Sistema de respaldos de carpetas para Windows, desarrollado en Python. Lee las rutas de origen y destino desde un archivo DBF y utiliza Robocopy para copiar y sincronizar los archivos. También ofrece una API con FastAPI para iniciar respaldos y consultar su estado.

## Requisitos

- Windows con `robocopy` disponible.
- Python 3.10 o superior.
- Paquetes `fastapi` y `uvicorn` para ejecutar la API.
- Archivo `dir.DBF` ubicado en la misma carpeta que el programa Python.
- Permisos de lectura sobre las carpetas de origen y de escritura sobre los destinos.

## Instalación

En una terminal, dentro de la carpeta del proyecto:

```powershell
python -m pip install fastapi uvicorn

## Configuración de dir.DBF

El archivo `dir.DBF` debe contener, como mínimo, los campos ORIGEN y DESTINO, con las rutas de las carpetas que se van a respaldar. El programa omite los registros marcados como eliminados y aquellos en los que alguna de las dos rutas esté vacía.

Ejemplo de contenido:

 ORIGEN  DESTINO 

 C:\Datos  D:\Respaldos\Datos

C:\Documentos  \\Servidor\Respaldos\Documentos

## Ejecución directa

Si el código se guarda como `rovobak.py`, ejecuta:

```powershell
python rovobak.py

El programa leerá `dir.DBF` y procesará las rutas una por una, mostrando los resultados en la consola.

## Ejecución de la API

Desde la carpeta del proyecto:

```powershell
python -m uvicorn rovobak:app --host 127.0.0.1 --port 8000


## Endpoints

 Método  uta  Función 
 GET    Comprueba que la API funciona 
 GET  rutas  Muestra las rutas de origen y destino del DBF 
 GET  estado  Consulta el estado y el resultado del último respaldo 


La solicitud de inicio responde con HTTP 202 cuando se inicia el proceso en segundo plano. Si ya hay un respaldo ejecutándose, responde con HTTP 409.

Los posibles valores de `estado` son `inactivo`, `ejecutando`, `finalizado` y `fallido`. El campo `resultado` indica `true`, `false` o `null`; el campo `error` registra errores no controlados del proceso en segundo plano.

## Opciones de Robocopy

El programa utiliza:

robocopy ORIGEN DESTINO E MIR R:3 /W:5 /Z /NP

- `/E`: incluye subcarpetas, incluso vacías
- `/MIR`: refleja el origen en el destino
- `/R:3`: realiza hasta tres reintentos ante errores de copia
- `/W:5`: espera cinco segundos entre reintentos
- `/Z`: utiliza el modo de copia reiniciable
- `/NP`: omite el porcentaje de progreso
## Manejo de resultados

El programa considera correctos los códigos de salida de Robocopy del 0 al 7 y considera error un código superior a 7. Si una carpeta de origen no existe, informa del problema y continúa con las demás rutas. El resultado global es satisfactorio únicamente cuando todas las rutas procesadas se consideran correctas.

## Consideraciones

- Los respaldos se ejecutan secuencialmente, en el orden de los registros del DBF.
- La API permite una sola ejecución de respaldo a la vez dentro del proceso de la aplicación.
- El estado se almacena en memoria y se reinicia al reiniciar el servidor.
- El proceso en segundo plano utiliza un hilo daemon; si se detiene la aplicación, el respaldo podría interrumpirse.
- La API no incluye autenticación. No debe exponerse a Internet sin implementar controles de acceso y seguridad adecuados.
- Para evitar ejecuciones simultáneas o estados inconsistentes, utiliza un solo proceso de servidor API.
