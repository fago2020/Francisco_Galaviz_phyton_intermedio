import os
import struct
import subprocess
from pathlib import Path
from threading import Lock, Thread
from fastapi import FastAPI, HTTPException


class RutaRespaldo:
    def __init__(self, origen, destino):
        self.origen = origen
        self.destino = destino

    @property
    def origen(self):
        return self._origen

    @origen.setter
    def origen(self, valor):
        if not valor or not valor.strip():
            raise ValueError("La ruta de origen está vacía")
        self._origen = valor.strip()

    @property
    def destino(self):
        return self._destino

    @destino.setter
    def destino(self, valor):
        if not valor or not valor.strip():
            raise ValueError("La ruta de destino está vacía")
        self._destino = valor.strip()

    def __str__(self):
        return f"{self.origen} -> {self.destino}"


class LectorDBF:
    def __init__(self, archivo):
        self.archivo = Path(archivo)

    def leer(self):
        rutas = []
        with self.archivo.open("rb") as archivo:
            cabecera = archivo.read(32)
            if len(cabecera) != 32:
                raise ValueError("Cabecera DBF incompleta")
            cantidad = struct.unpack_from("<I", cabecera, 4)[0]
            inicio = struct.unpack_from("<H", cabecera, 8)[0]
            longitud = struct.unpack_from("<H", cabecera, 10)[0]
            campos = {}
            posicion = 1
            while archivo.tell() < inicio:
                descriptor = archivo.read(32)
                if not descriptor or descriptor[0] == 13:
                    break
                if len(descriptor) != 32:
                    raise ValueError("Descriptor DBF incompleto")
                nombre = descriptor[:11].split(b"\0", 1)[0].decode("ascii").upper()
                tamano = descriptor[16]
                campos[nombre] = (posicion, tamano)
                posicion += tamano
            if "ORIGEN" not in campos or "DESTINO" not in campos:
                raise ValueError("El DBF debe contener ORIGEN y DESTINO")
            archivo.seek(inicio)
            for _ in range(cantidad):
                registro = archivo.read(longitud)
                if len(registro) != longitud:
                    raise ValueError("Registro DBF incompleto")
                if registro[:1] == b"*":
                    continue
                valores = []
                for nombre in ("ORIGEN", "DESTINO"):
                    inicio_campo, tamano = campos[nombre]
                    valor = registro[inicio_campo:inicio_campo + tamano]
                    valores.append(valor.decode("cp1252").strip().strip("\x00"))
                if all(valores):
                    rutas.append(RutaRespaldo(*valores))
        return rutas


class Respaldo:
    def ejecutar(self, ruta):
        if not os.path.isdir(ruta.origen):
            print(f"La carpeta de origen no existe: {ruta.origen}")
            return False
        print(f"Iniciando respaldo: {ruta}")
        comando = ["robocopy", ruta.origen, ruta.destino, "/E", "/MIR", "/R:3", "/W:5", "/Z", "/NP"]
        try:
            resultado = subprocess.run(comando, capture_output=True, text=True, errors="replace")
        except OSError as error:
            print(f"Error al ejecutar ROBOCOPY: {error}")
            return False
        if resultado.stdout:
            print(resultado.stdout)
        if resultado.returncode <= 7:
            print(f"Respaldo completado correctamente: {ruta}")
            return True
        print(f"Error en ROBOCOPY. Código: {resultado.returncode}")
        if resultado.stderr:
            print(resultado.stderr)
        return False


class Aplicacion:
    def __init__(self, archivo_dbf):
        self.lector = LectorDBF(archivo_dbf)
        self.respaldo = Respaldo()

    def ejecutar(self):
        try:
            rutas = self.lector.leer()
        except (OSError, ValueError, UnicodeError) as error:
            print(f"Error al leer el archivo DBF: {error}")
            return False
        if not rutas:
            print("No hay rutas de respaldo en el archivo DBF")
            return False
        resultados = [self.respaldo.ejecutar(ruta) for ruta in rutas]
        return all(resultados)


app = FastAPI(title="Rovobak API", version="1.0")
aplicacion = Aplicacion(Path(__file__).with_name("dir.DBF"))
bloqueo = Lock()
estado = {"estado": "inactivo", "resultado": None, "error": None}


def ejecutar_en_segundo_plano():
    try:
        resultado = aplicacion.ejecutar()
        with bloqueo:
            estado.update(estado="finalizado" if resultado else "fallido", resultado=resultado)
    except Exception as error:
        with bloqueo:
            estado.update(estado="fallido", resultado=False, error=str(error))


@app.get("/")
def inicio():
    return {"mensaje": "Rovobak API funcionando"}


@app.get("/rutas")
def consultar_rutas():
    try:
        return [{"origen": ruta.origen, "destino": ruta.destino} for ruta in aplicacion.lector.leer()]
    except (OSError, ValueError, UnicodeError) as error:
        raise HTTPException(status_code=500, detail=str(error)) from error


@app.get("/estado")
def consultar_estado():
    with bloqueo:
        return estado.copy()


@app.post("/respaldo", status_code=202)
def iniciar_respaldo():
    with bloqueo:
        if estado["estado"] == "ejecutando":
            raise HTTPException(status_code=409, detail="Ya hay un respaldo en ejecución")
        estado.update(estado="ejecutando", resultado=None, error=None)
        try:
            Thread(target=ejecutar_en_segundo_plano, daemon=True).start()
        except RuntimeError as error:
            estado.update(estado="fallido", resultado=False, error=str(error))
            raise HTTPException(status_code=500, detail=str(error)) from error
    return {"mensaje": "Respaldo iniciado"}


if __name__ == "__main__":
    aplicacion.ejecutar()
