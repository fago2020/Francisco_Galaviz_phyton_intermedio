class Producto:
    moneda = "MXN"

    def __init__(self, nombre, precio, cantidad_en_inventario):
        self.nombre = nombre
        self.precio = precio
        self.cantidad_en_inventario = cantidad_en_inventario

    def valor_total(self):
        return self.precio * self.cantidad_en_inventario


producto1 = Producto("Teclado", 250, 10)
producto2 = Producto("Mouse", 150, 20)
producto3 = Producto("Monitor", 3000, 5)

print(producto1.valor_total(), producto1.moneda)
print(producto2.valor_total(), producto2.moneda)
print(producto3.valor_total(), producto3.moneda)