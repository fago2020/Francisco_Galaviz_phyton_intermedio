class Libro:
    def __init__(self, titulo, autor):
        self.titulo = titulo
        self.autor = autor
        self.__disponible = True

    @property
    def disponible(self):
        return self.__disponible

    def __str__(self):
        estado = "disponible" if self.disponible else "prestado"
        return f"{self.titulo}, de {self.autor} ({estado})"

    def prestar(self):
        if self.disponible:
            self.__disponible = False
            print(f"Préstamo realizado: {self.titulo}")
        else:
            print(f"El libro {self.titulo} ya está prestado.")

    def devolver(self):
        self.__disponible = True
        print(f"Devolución realizada: {self.titulo}")


class Biblioteca:
    def __init__(self):
        self.__libros = []

    def agregar(self, libro):
        self.__libros.append(libro)

    def listar(self):
        for libro in self.__libros:
            print(libro)

    def buscar(self, titulo):
        for libro in self.__libros:
            if libro.titulo.casefold() == titulo.casefold():
                return libro
        return None


class LibroDigital(Libro):
    def __init__(self, titulo, autor, formato):
        super().__init__(titulo, autor)
        self.formato = formato

    @property
    def disponible(self):
        return True

    def prestar(self):
        print(f"Puedes acceder a {self.titulo} en formato {self.formato}.")

    def devolver(self):
        print("Los libros digitales siempre están disponibles.")


biblioteca = Biblioteca()

biblioteca.agregar(Libro("Meditaciones", "Marco Aurelio"))
biblioteca.agregar(Libro("Don Quijote de la Mancha", "Miguel de Cervantes"))
biblioteca.agregar(Libro("La Odisea", "Homero"))

libro = biblioteca.buscar("Meditaciones")

if libro is not None:
    libro.prestar()
    libro.prestar()

biblioteca.agregar(
    LibroDigital("Orgullo y prejuicio", "Jane Austen", "PDF")
)

biblioteca.listar()