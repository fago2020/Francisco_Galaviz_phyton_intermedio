# Etapa 1

`presentar("Ana")`: nombre="Ana", saludo="Hola", formal=False.

`presentar(nombre="Luis", formal=True)`: nombre="Luis", saludo="Hola", formal=True.

`sumar(2, 3, 5)`: numeros=(2, 3, 5), resultado 10.

`crear_ficha("Ana", ciudad="Puebla", activo=True)`: nombre="Ana", datos={"ciudad":"Puebla", "activo":True}.

`saludar_edad("Ana", "muchos")`: edad="muchos" y se imprime "Ana tiene muchos años."

`presentar()` produce TypeError por faltar nombre.

`presentar("Ana", formal=True, "Hola")` produce SyntaxError porque hay un argumento posicional después de uno por nombre.

`presentar("Ana", "Hola", True)` produce TypeError porque formal solo admite nombre.

`sumar(numeros=[1, 2])` produce TypeError porque sumar no acepta el argumento nombrado numeros.

`nombre` y `saludo` aceptan posición o nombre; `formal` solo nombre por el asterisco. Si se omite `saludo`, vale "Hola". `*args` recibe una tupla y `**kwargs` un diccionario. Una anotación `int` no valida argumentos en una función Python normal; FastAPI/Pydantic sí valida los datos de solicitudes según las reglas declaradas.

# Etapa 2

`GET /` ejecuta `inicio` y devuelve 200. `GET /libros` ejecuta `listar_libros` y devuelve 200. `GET /libros/{libro_id}` ejecuta `obtener_libro` y `POST /libros` ejecuta `crear_libro`, que devuelve 201 porque crea un recurso. GET consulta y POST crea.

En `listar_libros`, `q` es opcional, se compara en minúsculas con cada título y se devuelven coincidencias. `limite` restringe el número de resultados después del filtro. `/libros?q=PYTHON&limite=1` devuelve el libro 2; `/libros?q=inexistente` devuelve []; `/libros?limite=0` devuelve 422.

`/libros/2` devuelve 200 y el libro 2; `/libros/999` llega a la función y devuelve 404; `/libros/abc` y `/libros/0` devuelven 422 antes de ejecutarla.

Ruta: `/libros/2` aporta `libro_id=2`. Consulta: `/libros?q=python&limite=1` aporta filtros. Cuerpo: `POST /libros` recibe JSON con titulo, autor y paginas. Los libros nuevos desaparecen al reiniciar porque solo se guardan en la lista en memoria.
