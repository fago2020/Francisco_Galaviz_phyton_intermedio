from fastapi import APIRouter

router = APIRouter(prefix="/cafeteria", tags=["Cafetería"])


@router.get("")
def obtener_cafeteria():
    return {"nombre": "Cafetería del campus", "horario": "Lunes a viernes de 8:00 a 18:00"}
